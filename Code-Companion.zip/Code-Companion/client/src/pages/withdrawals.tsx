import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Search,
  Filter,
  Check,
  X,
  Loader2,
  Clock,
  CheckCircle,
  XCircle,
  Wallet,
  ExternalLink,
} from "lucide-react";
import type { Withdrawal, WithdrawalAction } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

interface WithdrawalWithUser extends Withdrawal {
  user?: {
    username: string;
    email: string;
  };
}

export default function WithdrawalsPage() {
  const { admin } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<WithdrawalWithUser | null>(null);
  const [actionType, setActionType] = useState<"approve" | "reject" | null>(null);
  const [notes, setNotes] = useState("");

  const canProcess = admin?.role === "super_admin" || admin?.role === "finance_admin";

  const { data: withdrawals, isLoading } = useQuery<WithdrawalWithUser[]>({
    queryKey: ["/api/withdrawals"],
    refetchInterval: 10000,
  });

  const processWithdrawalMutation = useMutation({
    mutationFn: async (data: WithdrawalAction) => {
      const response = await apiRequest("POST", "/api/withdrawals/process", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/withdrawals"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
      toast({
        title: actionType === "approve" ? "Withdrawal Approved" : "Withdrawal Rejected",
        description: `Withdrawal request has been ${actionType}ed successfully.`,
      });
      closeDialog();
    },
    onError: (error: Error) => {
      toast({
        title: "Action Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const closeDialog = () => {
    setSelectedWithdrawal(null);
    setActionType(null);
    setNotes("");
  };

  const handleAction = (withdrawal: WithdrawalWithUser, action: "approve" | "reject") => {
    setSelectedWithdrawal(withdrawal);
    setActionType(action);
  };

  const confirmAction = () => {
    if (!selectedWithdrawal || !actionType) return;
    processWithdrawalMutation.mutate({
      withdrawalId: selectedWithdrawal.id,
      action: actionType,
      notes: notes || undefined,
    });
  };

  const filteredWithdrawals = withdrawals?.filter((w) => {
    const matchesSearch =
      searchQuery === "" ||
      w.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.walletAddress.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.user?.username?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || w.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="h-4 w-4" />;
      case "approved":
        return <CheckCircle className="h-4 w-4" />;
      case "rejected":
        return <XCircle className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getStatusVariant = (status: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (status) {
      case "pending":
        return "secondary";
      case "approved":
        return "default";
      case "rejected":
        return "destructive";
      default:
        return "outline";
    }
  };

  const formatAmount = (amount: string) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 8,
    }).format(parseFloat(amount));
  };

  const truncateAddress = (address: string) => {
    if (address.length <= 16) return address;
    return `${address.slice(0, 8)}...${address.slice(-8)}`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-withdrawals-title">
          Withdrawal Requests
        </h1>
        <p className="text-muted-foreground mt-1">
          Review and process user withdrawal requests
        </p>
      </div>

      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <CardTitle className="text-lg font-medium">All Requests</CardTitle>
            <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by ID, address, or user..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-full sm:w-64"
                  data-testid="input-search-withdrawals"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full sm:w-40" data-testid="select-status-filter">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="flex gap-4 items-center">
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 flex-1" />
                  <Skeleton className="h-10 w-24" />
                  <Skeleton className="h-10 w-20" />
                  <Skeleton className="h-10 w-32" />
                </div>
              ))}
            </div>
          ) : filteredWithdrawals && filteredWithdrawals.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Request ID</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Wallet Address</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWithdrawals.map((withdrawal) => (
                    <TableRow key={withdrawal.id} data-testid={`row-withdrawal-${withdrawal.id}`}>
                      <TableCell className="font-mono text-sm">
                        {withdrawal.id.slice(0, 8)}...
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{withdrawal.user?.username || "Unknown"}</p>
                          <p className="text-sm text-muted-foreground">
                            {withdrawal.user?.email || "-"}
                          </p>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono font-medium">
                        {formatAmount(withdrawal.amount)}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Wallet className="h-4 w-4 text-muted-foreground" />
                          <span className="font-mono text-sm">
                            {truncateAddress(withdrawal.walletAddress)}
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => navigator.clipboard.writeText(withdrawal.walletAddress)}
                            data-testid={`button-copy-address-${withdrawal.id}`}
                          >
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusVariant(withdrawal.status)} className="gap-1">
                          {getStatusIcon(withdrawal.status)}
                          {withdrawal.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {format(new Date(withdrawal.createdAt), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell className="text-right">
                        {withdrawal.status === "pending" && canProcess ? (
                          <div className="flex justify-end gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleAction(withdrawal, "approve")}
                              data-testid={`button-approve-${withdrawal.id}`}
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleAction(withdrawal, "reject")}
                              data-testid={`button-reject-${withdrawal.id}`}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        ) : withdrawal.status === "pending" ? (
                          <span className="text-sm text-muted-foreground">No permission</span>
                        ) : (
                          <span className="text-sm text-muted-foreground">Processed</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Wallet className="h-16 w-16 text-muted-foreground/50 mb-4" />
              <h3 className="text-lg font-medium">No withdrawal requests</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {searchQuery || statusFilter !== "all"
                  ? "No requests match your filters"
                  : "Withdrawal requests will appear here when users submit them"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selectedWithdrawal && !!actionType} onOpenChange={() => closeDialog()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === "approve" ? "Approve" : "Reject"} Withdrawal
            </DialogTitle>
            <DialogDescription>
              {actionType === "approve"
                ? "This will approve the withdrawal and mark it for processing."
                : "This will reject the withdrawal request. The user will be notified."}
            </DialogDescription>
          </DialogHeader>

          {selectedWithdrawal && (
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Amount</p>
                  <p className="font-mono font-medium">
                    {formatAmount(selectedWithdrawal.amount)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">User</p>
                  <p className="font-medium">
                    {selectedWithdrawal.user?.username || "Unknown"}
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground">Wallet Address</p>
                  <p className="font-mono text-sm break-all">
                    {selectedWithdrawal.walletAddress}
                  </p>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">
                  Notes (optional)
                </label>
                <Textarea
                  placeholder="Add any notes about this decision..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="mt-2"
                  data-testid="input-action-notes"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>
              Cancel
            </Button>
            <Button
              variant={actionType === "reject" ? "destructive" : "default"}
              onClick={confirmAction}
              disabled={processWithdrawalMutation.isPending}
              data-testid="button-confirm-action"
            >
              {processWithdrawalMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  {actionType === "approve" ? (
                    <Check className="h-4 w-4 mr-2" />
                  ) : (
                    <X className="h-4 w-4 mr-2" />
                  )}
                  Confirm {actionType === "approve" ? "Approval" : "Rejection"}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
