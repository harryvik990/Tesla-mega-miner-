import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, subDays, subMonths } from "date-fns";
import {
  TrendingUp,
  Users,
  ArrowDownUp,
  DollarSign,
  Calendar,
  Download,
  RefreshCw,
} from "lucide-react";
import type { AnalyticsData } from "@shared/schema";
import { MetricCard } from "@/components/metric-card";
import { TransactionVolumeChart, UserGrowthChart, FeeDistributionChart } from "@/components/charts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type DateRange = "7d" | "30d" | "90d" | "1y";

export default function AnalyticsPage() {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState<DateRange>("30d");

  const { data: analytics, isLoading, isFetching } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics", dateRange],
    refetchInterval: 60000,
  });

  const getDateRangeLabel = (range: DateRange): string => {
    switch (range) {
      case "7d":
        return "Last 7 days";
      case "30d":
        return "Last 30 days";
      case "90d":
        return "Last 90 days";
      case "1y":
        return "Last year";
    }
  };

  const getStartDate = (range: DateRange): Date => {
    switch (range) {
      case "7d":
        return subDays(new Date(), 7);
      case "30d":
        return subDays(new Date(), 30);
      case "90d":
        return subDays(new Date(), 90);
      case "1y":
        return subMonths(new Date(), 12);
    }
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/analytics"] });
    toast({
      title: "Refreshing Data",
      description: "Analytics data is being updated...",
    });
  };

  const handleExport = () => {
    if (!analytics) return;

    const csvData = [
      ["Metric", "Value"],
      ["Total Users", analytics.totalUsers.toString()],
      ["Total Transactions", analytics.totalTransactions.toString()],
      ["Total Volume", analytics.totalVolume],
      ["Total Fees", analytics.totalFees],
      ["Pending Withdrawals", analytics.pendingWithdrawals.toString()],
    ];

    const csvContent = csvData.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `analytics-${format(new Date(), "yyyy-MM-dd")}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Export Complete",
      description: "Analytics data has been downloaded.",
    });
  };

  const transactionVolumeData = analytics?.transactionVolume.map((item) => ({
    date: item.date,
    value: parseFloat(item.volume),
  })) || [];

  const userGrowthData = analytics?.userGrowth.map((item) => ({
    name: item.date,
    value: item.count,
  })) || [];

  const feeDistributionData = analytics?.feeDistribution.map((item) => ({
    name: item.type,
    value: parseFloat(item.amount),
  })) || [];

  const formatCurrency = (value: string | undefined) => {
    if (!value) return "$0.00";
    const num = parseFloat(value);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-analytics-title">
            Analytics
          </h1>
          <p className="text-muted-foreground mt-1">
            Detailed insights and platform metrics
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={dateRange} onValueChange={(v: DateRange) => setDateRange(v)}>
            <SelectTrigger className="w-40" data-testid="select-date-range">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={isFetching}
            data-testid="button-refresh-analytics"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isFetching ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button
            variant="outline"
            onClick={handleExport}
            disabled={!analytics}
            data-testid="button-export-analytics"
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="text-sm text-muted-foreground flex items-center gap-2">
        <Calendar className="h-4 w-4" />
        <span>
          {format(getStartDate(dateRange), "MMM d, yyyy")} - {format(new Date(), "MMM d, yyyy")}
        </span>
        <span className="text-muted-foreground/50">|</span>
        <span>{getDateRangeLabel(dateRange)}</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Users"
          value={analytics?.totalUsers.toLocaleString() || "0"}
          change={12.5}
          icon={<Users className="h-4 w-4" />}
          loading={isLoading}
          testId="card-analytics-users"
        />
        <MetricCard
          title="Total Transactions"
          value={analytics?.totalTransactions.toLocaleString() || "0"}
          change={8.2}
          icon={<ArrowDownUp className="h-4 w-4" />}
          loading={isLoading}
          testId="card-analytics-transactions"
        />
        <MetricCard
          title="Total Volume"
          value={formatCurrency(analytics?.totalVolume)}
          change={23.1}
          icon={<TrendingUp className="h-4 w-4" />}
          loading={isLoading}
          testId="card-analytics-volume"
        />
        <MetricCard
          title="Total Fees"
          value={formatCurrency(analytics?.totalFees)}
          change={15.3}
          icon={<DollarSign className="h-4 w-4" />}
          loading={isLoading}
          testId="card-analytics-fees"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TransactionVolumeChart data={transactionVolumeData} loading={isLoading} />
        <UserGrowthChart data={userGrowthData} loading={isLoading} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <FeeDistributionChart data={feeDistributionData} loading={isLoading} />

        <Card className="lg:col-span-2" data-testid="card-analytics-summary">
          <CardHeader>
            <CardTitle className="text-lg font-medium">
              Period Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Metric</TableHead>
                    <TableHead className="text-right">Value</TableHead>
                    <TableHead className="text-right">Change</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">New Users</TableCell>
                    <TableCell className="text-right font-mono">
                      {analytics?.totalUsers.toLocaleString() || "0"}
                    </TableCell>
                    <TableCell className="text-right text-green-600 dark:text-green-400">
                      +12.5%
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Transaction Count</TableCell>
                    <TableCell className="text-right font-mono">
                      {analytics?.totalTransactions.toLocaleString() || "0"}
                    </TableCell>
                    <TableCell className="text-right text-green-600 dark:text-green-400">
                      +8.2%
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Trading Volume</TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(analytics?.totalVolume)}
                    </TableCell>
                    <TableCell className="text-right text-green-600 dark:text-green-400">
                      +23.1%
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Fee Revenue</TableCell>
                    <TableCell className="text-right font-mono">
                      {formatCurrency(analytics?.totalFees)}
                    </TableCell>
                    <TableCell className="text-right text-green-600 dark:text-green-400">
                      +15.3%
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Pending Withdrawals</TableCell>
                    <TableCell className="text-right font-mono">
                      {analytics?.pendingWithdrawals || 0}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      -
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
