import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  Settings,
  Save,
  Loader2,
  Percent,
  DollarSign,
  History,
  Calculator,
  Info,
} from "lucide-react";
import type { Config, AuditLog } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface FeeConfig {
  tradingFee: string;
  withdrawalFee: string;
  depositFee: string;
  minWithdrawal: string;
  maxWithdrawal: string;
}

export default function FeesPage() {
  const { admin } = useAuth();
  const { toast } = useToast();
  const [feeConfig, setFeeConfig] = useState<FeeConfig>({
    tradingFee: "0.1",
    withdrawalFee: "0.5",
    depositFee: "0",
    minWithdrawal: "10",
    maxWithdrawal: "10000",
  });
  const [previewAmount, setPreviewAmount] = useState("1000");

  const canEdit = admin?.role === "super_admin" || admin?.role === "finance_admin";

  const { data: configs, isLoading: configsLoading } = useQuery<Config[]>({
    queryKey: ["/api/config"],
  });

  const { data: feeHistory, isLoading: historyLoading } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit-logs", "config"],
  });

  useEffect(() => {
    if (configs) {
      const configMap: Record<string, string> = {};
      configs.forEach((c) => {
        configMap[c.name] = c.value;
      });
      setFeeConfig({
        tradingFee: configMap["trading_fee"] || "0.1",
        withdrawalFee: configMap["withdrawal_fee"] || "0.5",
        depositFee: configMap["deposit_fee"] || "0",
        minWithdrawal: configMap["min_withdrawal"] || "10",
        maxWithdrawal: configMap["max_withdrawal"] || "10000",
      });
    }
  }, [configs]);

  const updateConfigMutation = useMutation({
    mutationFn: async (updates: { name: string; value: string }[]) => {
      const promises = updates.map((update) =>
        apiRequest("POST", "/api/config", update)
      );
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/config"] });
      queryClient.invalidateQueries({ queryKey: ["/api/audit-logs"] });
      toast({
        title: "Configuration Updated",
        description: "Fee settings have been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const updates = [
      { name: "trading_fee", value: feeConfig.tradingFee },
      { name: "withdrawal_fee", value: feeConfig.withdrawalFee },
      { name: "deposit_fee", value: feeConfig.depositFee },
      { name: "min_withdrawal", value: feeConfig.minWithdrawal },
      { name: "max_withdrawal", value: feeConfig.maxWithdrawal },
    ];
    updateConfigMutation.mutate(updates);
  };

  const calculatePreview = () => {
    const amount = parseFloat(previewAmount) || 0;
    const tradingFeeAmount = amount * (parseFloat(feeConfig.tradingFee) / 100);
    const withdrawalFeeAmount = amount * (parseFloat(feeConfig.withdrawalFee) / 100);
    const depositFeeAmount = amount * (parseFloat(feeConfig.depositFee) / 100);
    return {
      tradingFee: tradingFeeAmount.toFixed(2),
      withdrawalFee: withdrawalFeeAmount.toFixed(2),
      depositFee: depositFeeAmount.toFixed(2),
      netAfterTrade: (amount - tradingFeeAmount).toFixed(2),
      netAfterWithdrawal: (amount - withdrawalFeeAmount).toFixed(2),
    };
  };

  const preview = calculatePreview();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="text-fees-title">
          Fee Configuration
        </h1>
        <p className="text-muted-foreground mt-1">
          Manage platform fees and transaction limits
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Fee Settings
              </CardTitle>
              <CardDescription>
                Configure trading and transaction fees
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {configsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="tradingFee">Trading Fee</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Percentage charged on each trade</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="relative">
                      <Input
                        id="tradingFee"
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        value={feeConfig.tradingFee}
                        onChange={(e) =>
                          setFeeConfig({ ...feeConfig, tradingFee: e.target.value })
                        }
                        disabled={!canEdit}
                        className="pr-8"
                        data-testid="input-trading-fee"
                      />
                      <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="withdrawalFee">Withdrawal Fee</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Percentage charged on withdrawals</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="relative">
                      <Input
                        id="withdrawalFee"
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        value={feeConfig.withdrawalFee}
                        onChange={(e) =>
                          setFeeConfig({ ...feeConfig, withdrawalFee: e.target.value })
                        }
                        disabled={!canEdit}
                        className="pr-8"
                        data-testid="input-withdrawal-fee"
                      />
                      <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="depositFee">Deposit Fee</Label>
                      <Tooltip>
                        <TooltipTrigger>
                          <Info className="h-4 w-4 text-muted-foreground" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Percentage charged on deposits</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="relative">
                      <Input
                        id="depositFee"
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        value={feeConfig.depositFee}
                        onChange={(e) =>
                          setFeeConfig({ ...feeConfig, depositFee: e.target.value })
                        }
                        disabled={!canEdit}
                        className="pr-8"
                        data-testid="input-deposit-fee"
                      />
                      <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="minWithdrawal">Minimum Withdrawal</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="minWithdrawal"
                        type="number"
                        step="1"
                        min="0"
                        value={feeConfig.minWithdrawal}
                        onChange={(e) =>
                          setFeeConfig({ ...feeConfig, minWithdrawal: e.target.value })
                        }
                        disabled={!canEdit}
                        className="pl-8"
                        data-testid="input-min-withdrawal"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxWithdrawal">Maximum Withdrawal</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="maxWithdrawal"
                        type="number"
                        step="1"
                        min="0"
                        value={feeConfig.maxWithdrawal}
                        onChange={(e) =>
                          setFeeConfig({ ...feeConfig, maxWithdrawal: e.target.value })
                        }
                        disabled={!canEdit}
                        className="pl-8"
                        data-testid="input-max-withdrawal"
                      />
                    </div>
                  </div>

                  <Button
                    className="w-full mt-4"
                    onClick={handleSave}
                    disabled={!canEdit || updateConfigMutation.isPending}
                    data-testid="button-save-config"
                  >
                    {updateConfigMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Changes
                      </>
                    )}
                  </Button>

                  {!canEdit && (
                    <p className="text-sm text-muted-foreground text-center">
                      You need Finance Admin or Super Admin role to edit fees
                    </p>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Fee Calculator
              </CardTitle>
              <CardDescription>
                Preview how fees will affect transactions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="previewAmount">Transaction Amount</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="previewAmount"
                      type="number"
                      step="0.01"
                      min="0"
                      value={previewAmount}
                      onChange={(e) => setPreviewAmount(e.target.value)}
                      className="pl-8"
                      data-testid="input-preview-amount"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-md">
                    <p className="text-sm text-muted-foreground">Trading Fee</p>
                    <p className="text-2xl font-mono font-bold" data-testid="text-preview-trading-fee">
                      ${preview.tradingFee}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Net: ${preview.netAfterTrade}
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-md">
                    <p className="text-sm text-muted-foreground">Withdrawal Fee</p>
                    <p className="text-2xl font-mono font-bold" data-testid="text-preview-withdrawal-fee">
                      ${preview.withdrawalFee}
                    </p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Net: ${preview.netAfterWithdrawal}
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-md">
                    <p className="text-sm text-muted-foreground">Deposit Fee</p>
                    <p className="text-2xl font-mono font-bold" data-testid="text-preview-deposit-fee">
                      ${preview.depositFee}
                    </p>
                  </div>
                  <div className="p-4 bg-muted rounded-md">
                    <p className="text-sm text-muted-foreground">Withdrawal Limits</p>
                    <p className="text-lg font-mono font-medium">
                      ${parseFloat(feeConfig.minWithdrawal).toLocaleString()} - $
                      {parseFloat(feeConfig.maxWithdrawal).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="h-5 w-5" />
                Configuration History
              </CardTitle>
              <CardDescription>
                Recent changes to fee settings
              </CardDescription>
            </CardHeader>
            <CardContent>
              {historyLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : feeHistory && feeHistory.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Action</TableHead>
                      <TableHead>Setting</TableHead>
                      <TableHead>Old Value</TableHead>
                      <TableHead>New Value</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {feeHistory.slice(0, 10).map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="font-medium">
                          {log.action.replace(/_/g, " ")}
                        </TableCell>
                        <TableCell>{log.entityId || "-"}</TableCell>
                        <TableCell className="font-mono text-sm">
                          {log.oldValue || "-"}
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {log.newValue || "-"}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {format(new Date(log.createdAt), "MMM d, yyyy h:mm a")}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <History className="h-12 w-12 text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No configuration changes yet</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Changes will be logged here when settings are updated
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
