import { useQuery } from "@tanstack/react-query";
import { Users, ArrowDownUp, DollarSign, Clock, Activity } from "lucide-react";
import type { AnalyticsData, AuditLog } from "@shared/schema";
import { MetricCard } from "@/components/metric-card";
import { TransactionVolumeChart, UserGrowthChart, FeeDistributionChart } from "@/components/charts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";

export default function DashboardPage() {
  const { data: analytics, isLoading: analyticsLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics"],
    refetchInterval: 30000,
  });

  const { data: recentActivity, isLoading: activityLoading } = useQuery<AuditLog[]>({
    queryKey: ["/api/audit-logs/recent"],
  });

  const transactionVolumeData = analytics?.transactionVolume.map((item) => ({
    date: item.date,
    value: parseFloat(item.volume),
  })) || [];

  const userGrowthData = analytics?.userGrowth.map((item) => ({
    name: item.date,
    value: item.count,
  })) || [];

  const feeDistributionData = analytics?.feeDistribution.map((item) => ({
    name: item.type,
    value: parseFloat(item.amount),
  })) || [];

  const formatCurrency = (value: string | undefined) => {
    if (!value) return "$0.00";
    const num = parseFloat(value);
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  };

  const getActionBadgeVariant = (action: string): "default" | "secondary" | "destructive" | "outline" => {
    if (action.includes("approve")) return "default";
    if (action.includes("reject")) return "destructive";
    if (action.includes("update")) return "secondary";
    return "outline";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-dashboard-title">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Overview of platform performance and metrics
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 text-green-600 dark:text-green-400 rounded-md text-sm font-medium">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            Live
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Total Users"
          value={analytics?.totalUsers.toLocaleString() || "0"}
          change={12.5}
          icon={<Users className="h-4 w-4" />}
          loading={analyticsLoading}
          testId="card-total-users"
        />
        <MetricCard
          title="Total Transactions"
          value={analytics?.totalTransactions.toLocaleString() || "0"}
          change={8.2}
          icon={<ArrowDownUp className="h-4 w-4" />}
          loading={analyticsLoading}
          testId="card-total-transactions"
        />
        <MetricCard
          title="Total Fees Collected"
          value={formatCurrency(analytics?.totalFees)}
          change={15.3}
          icon={<DollarSign className="h-4 w-4" />}
          loading={analyticsLoading}
          testId="card-total-fees"
        />
        <MetricCard
          title="Pending Withdrawals"
          value={analytics?.pendingWithdrawals || 0}
          icon={<Clock className="h-4 w-4" />}
          loading={analyticsLoading}
          testId="card-pending-withdrawals"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <TransactionVolumeChart data={transactionVolumeData} loading={analyticsLoading} />
        <div className="grid grid-cols-1 gap-4">
          <UserGrowthChart data={userGrowthData} loading={analyticsLoading} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <FeeDistributionChart data={feeDistributionData} loading={analyticsLoading} />
        <Card className="lg:col-span-2" data-testid="card-recent-activity">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[280px] pr-4">
              {activityLoading ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex items-start gap-3 animate-pulse">
                      <div className="w-8 h-8 rounded-full bg-muted" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 w-3/4 bg-muted rounded" />
                        <div className="h-3 w-1/4 bg-muted rounded" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : recentActivity && recentActivity.length > 0 ? (
                <div className="space-y-4">
                  {recentActivity.map((log) => (
                    <div
                      key={log.id}
                      className="flex items-start gap-3 pb-4 border-b border-border last:border-0 last:pb-0"
                      data-testid={`activity-${log.id}`}
                    >
                      <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                        <Activity className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge variant={getActionBadgeVariant(log.action)} className="text-xs">
                            {log.action.replace(/_/g, " ")}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            {log.entityType}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(log.createdAt), "MMM d, yyyy 'at' h:mm a")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center py-8">
                  <Activity className="h-12 w-12 text-muted-foreground/50 mb-3" />
                  <p className="text-muted-foreground">No recent activity</p>
                  <p className="text-sm text-muted-foreground/70 mt-1">
                    Actions will appear here as they occur
                  </p>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
