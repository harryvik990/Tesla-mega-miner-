# Admin Panel & Analytics Dashboard - Design Guidelines

## Design Approach

**System**: Material Design with inspirations from Stripe Dashboard, Vercel Analytics, and Linear's data presentation
**Rationale**: Data-heavy admin interfaces require established patterns for efficiency, scanability, and trust. Material Design provides robust components for complex data displays while maintaining visual hierarchy.

## Typography System

**Font Family**: Inter (primary), JetBrains Mono (code/data)
- Page Headers: text-3xl font-bold
- Section Headers: text-xl font-semibold  
- Card Titles: text-lg font-medium
- Body Text: text-base font-normal
- Data/Metrics: text-sm font-mono (for numerical values)
- Helper Text: text-sm text-gray-500

## Layout System

**Spacing Primitives**: Tailwind units of 4, 6, 8, 12, 16
- Component padding: p-6
- Section gaps: gap-8
- Card spacing: p-4 to p-6
- Tight data tables: p-2 to p-4

**Grid System**:
- Dashboard: 12-column grid (grid-cols-12)
- Analytics cards: 3-column on desktop (lg:grid-cols-3), 1-column mobile
- Main content area: max-w-7xl mx-auto
- Sidebar width: w-64 fixed

## Core Layout Structure

### 1. Admin Shell
- Fixed sidebar navigation (left, w-64)
- Top navigation bar with user profile, notifications, logout
- Main content area with breadcrumbs
- Sticky header for tables/lists

### 2. Dashboard Overview (Home)
**Layout**: 
- Top row: 4 metric cards (grid-cols-4) showing: Total Users, Total Transactions, Fees Collected, Pending Withdrawals
- Middle section: 2-column layout (grid-cols-2)
  - Left: Large chart area (Transaction Volume Over Time - Line Chart)
  - Right: Smaller charts (Fee Distribution - Pie Chart, User Growth - Bar Chart)
- Bottom: Recent Activity feed (full width)

### 3. Withdrawal Management Page
**Layout**:
- Filter bar at top (status dropdown, search, date range)
- Data table with columns: Request ID, User, Amount, Date, Status, Actions
- Pagination footer
- Side drawer for approval workflow (slides in from right)

### 4. Fee Configuration Page
**Layout**:
- Left panel: Configuration form (w-1/3)
- Right panel: Live preview/impact calculator (w-2/3)
- Historical changes log below (full width table)

### 5. Analytics Dashboard
**Layout**:
- Date range selector (top right)
- KPI summary cards (grid-cols-4)
- Chart grid below (grid-cols-2 for large charts, grid-cols-3 for smaller metrics)
- Exportable data tables at bottom

## Component Library

### Navigation
- Sidebar: Icon + label menu items, grouped by category, active state with accent
- Breadcrumbs: Chevron separators, last item bold
- Tabs: Underline style for sub-navigation

### Data Display
- Metric Cards: Large number, label below, trend indicator (↑/↓), sparkline mini-chart
- Data Tables: Zebra striping, sortable headers, row hover, sticky header, action buttons right-aligned
- Charts: Chart.js components with consistent color palette, tooltips on hover, legend positioned top-right

### Forms & Controls
- Input fields: Outlined style, label above, helper text below
- Dropdowns: Native select enhanced with search for long lists
- Toggle switches: For binary settings
- Action buttons: Primary (approve), Danger (reject), Secondary (cancel)

### Status Indicators
- Badges: Pill-shaped, color-coded (pending: yellow, approved: green, rejected: red)
- Progress indicators: For multi-step workflows
- Toast notifications: Top-right positioning for system feedback

### Modals & Drawers
- Confirmation dialogs: Centered modal with action buttons
- Detail drawers: Slide from right (w-96), overlay background
- Multi-step wizards: Stepper at top, form sections, navigation buttons

## Data Visualization Specifications

**Chart Types**:
1. **Line Charts**: Transaction volume over time, user growth trends
   - Grid lines subtle, axis labels clear
   - Data points on hover, line thickness: 2px
   
2. **Bar Charts**: Comparative metrics (monthly fees, user segments)
   - Bar width consistent, gap between bars: 4px
   - Horizontal layout for long labels

3. **Pie/Donut Charts**: Distribution metrics (fee breakdown, user types)
   - Segment labels with percentages
   - Legend beside chart, not below

**Chart Container**: 
- Card wrapper with p-6
- Title at top-left, export button top-right
- Chart canvas with aspect-ratio-16/9 or square for pie charts

## Audit Trail & Activity Log

**Layout**: Timeline style (left border accent)
- Avatar/icon on left
- Action description, timestamp, user name
- Expandable details on click
- Grouped by date with date headers

## Responsive Behavior

**Desktop (lg)**: Full sidebar visible, multi-column grids
**Tablet (md)**: Collapsible sidebar (hamburger), 2-column max
**Mobile**: Hidden sidebar (drawer), single column, simplified tables (card view)

## Real-Time Updates

**Visual Treatment**:
- Pulse animation on metric cards when data updates
- Subtle flash effect on new table rows
- "Live" indicator badge in top navigation
- Auto-refresh toggle switch in chart controls

## Empty States

- Centered icon + message for empty tables
- Actionable CTA button below message
- Illustration for major empty states (no withdrawals pending)

## Loading States

- Skeleton screens for data tables and charts
- Spinner overlay for form submissions
- Progress bar for bulk operations

## Images

This admin dashboard is data-focused and does NOT require hero images or decorative imagery. Use icons throughout:
- **Icon Library**: Heroicons (outline for navigation, solid for metrics)
- **Chart Icons**: In metric cards (trending-up, currency-dollar, users, etc.)
- **Empty State Illustrations**: Simple line-art illustrations for empty tables/no data states
- **User Avatars**: Circular, 32px for tables, 48px for detail views