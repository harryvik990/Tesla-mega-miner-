import {
  admins,
  users,
  transactions,
  withdrawals,
  config,
  auditLogs,
  type Admin,
  type InsertAdmin,
  type User,
  type InsertUser,
  type Transaction,
  type InsertTransaction,
  type Withdrawal,
  type InsertWithdrawal,
  type Config,
  type InsertConfig,
  type AuditLog,
  type InsertAuditLog,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, count, sum } from "drizzle-orm";

export interface IStorage {
  // Admin operations
  getAdmin(id: string): Promise<Admin | undefined>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;

  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  getUserCount(): Promise<number>;

  // Transaction operations
  getTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionStats(): Promise<{ totalCount: number; totalVolume: string; totalFees: string }>;

  // Withdrawal operations
  getWithdrawals(): Promise<(Withdrawal & { user?: { username: string; email: string } })[]>;
  getWithdrawal(id: string): Promise<Withdrawal | undefined>;
  createWithdrawal(withdrawal: InsertWithdrawal): Promise<Withdrawal>;
  updateWithdrawal(id: string, data: Partial<Withdrawal>): Promise<Withdrawal | undefined>;
  getPendingWithdrawalsCount(): Promise<number>;

  // Config operations
  getConfigs(): Promise<Config[]>;
  getConfig(name: string): Promise<Config | undefined>;
  upsertConfig(configData: InsertConfig): Promise<Config>;

  // Audit log operations
  getAuditLogs(entityType?: string, limit?: number): Promise<AuditLog[]>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
}

export class DatabaseStorage implements IStorage {
  // Admin operations
  async getAdmin(id: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.id, id));
    return admin || undefined;
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    const [admin] = await db.select().from(admins).where(eq(admins.username, username));
    return admin || undefined;
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const [admin] = await db.insert(admins).values(insertAdmin).returning();
    return admin;
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getUserCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(users);
    return result?.count || 0;
  }

  // Transaction operations
  async getTransactions(): Promise<Transaction[]> {
    return db.select().from(transactions).orderBy(desc(transactions.createdAt));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db.insert(transactions).values(insertTransaction).returning();
    return transaction;
  }

  async getTransactionStats(): Promise<{ totalCount: number; totalVolume: string; totalFees: string }> {
    const [result] = await db
      .select({
        totalCount: count(),
        totalVolume: sql<string>`COALESCE(SUM(${transactions.amount}), 0)::text`,
        totalFees: sql<string>`COALESCE(SUM(${transactions.fee}), 0)::text`,
      })
      .from(transactions);
    return {
      totalCount: result?.totalCount || 0,
      totalVolume: result?.totalVolume || "0",
      totalFees: result?.totalFees || "0",
    };
  }

  // Withdrawal operations
  async getWithdrawals(): Promise<(Withdrawal & { user?: { username: string; email: string } })[]> {
    const results = await db
      .select({
        withdrawal: withdrawals,
        user: {
          username: users.username,
          email: users.email,
        },
      })
      .from(withdrawals)
      .leftJoin(users, eq(withdrawals.userId, users.id))
      .orderBy(desc(withdrawals.createdAt));

    return results.map((r) => ({
      ...r.withdrawal,
      user: r.user || undefined,
    }));
  }

  async getWithdrawal(id: string): Promise<Withdrawal | undefined> {
    const [withdrawal] = await db.select().from(withdrawals).where(eq(withdrawals.id, id));
    return withdrawal || undefined;
  }

  async createWithdrawal(insertWithdrawal: InsertWithdrawal): Promise<Withdrawal> {
    const [withdrawal] = await db.insert(withdrawals).values(insertWithdrawal).returning();
    return withdrawal;
  }

  async updateWithdrawal(id: string, data: Partial<Withdrawal>): Promise<Withdrawal | undefined> {
    const [updated] = await db
      .update(withdrawals)
      .set(data)
      .where(eq(withdrawals.id, id))
      .returning();
    return updated || undefined;
  }

  async getPendingWithdrawalsCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(withdrawals)
      .where(eq(withdrawals.status, "pending"));
    return result?.count || 0;
  }

  // Config operations
  async getConfigs(): Promise<Config[]> {
    return db.select().from(config).orderBy(config.name);
  }

  async getConfig(name: string): Promise<Config | undefined> {
    const [configItem] = await db.select().from(config).where(eq(config.name, name));
    return configItem || undefined;
  }

  async upsertConfig(configData: InsertConfig): Promise<Config> {
    const existing = await this.getConfig(configData.name);
    if (existing) {
      const [updated] = await db
        .update(config)
        .set({
          value: configData.value,
          description: configData.description,
          updatedBy: configData.updatedBy,
          updatedAt: new Date(),
        })
        .where(eq(config.name, configData.name))
        .returning();
      return updated;
    }
    const [created] = await db.insert(config).values(configData).returning();
    return created;
  }

  // Audit log operations
  async getAuditLogs(entityType?: string, limit: number = 50): Promise<AuditLog[]> {
    if (entityType) {
      return db
        .select()
        .from(auditLogs)
        .where(eq(auditLogs.entityType, entityType))
        .orderBy(desc(auditLogs.createdAt))
        .limit(limit);
    }
    return db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(limit);
  }

  async createAuditLog(insertLog: InsertAuditLog): Promise<AuditLog> {
    const [log] = await db.insert(auditLogs).values(insertLog).returning();
    return log;
  }
}

export const storage = new DatabaseStorage();
