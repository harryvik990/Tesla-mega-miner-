import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import {
  loginSchema,
  withdrawalActionSchema,
  configUpdateSchema,
  type AnalyticsData,
} from "@shared/schema";
import bcrypt from "bcrypt";
import { randomUUID } from "crypto";

declare module "express-session" {
  interface SessionData {
    adminId?: string;
  }
}

// Middleware to require authentication
function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.adminId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  next();
}

// Middleware to require specific roles
function requireRole(...roles: string[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.session.adminId) {
      return res.status(401).json({ error: "Authentication required" });
    }
    const admin = await storage.getAdmin(req.session.adminId);
    if (!admin || !roles.includes(admin.role)) {
      return res.status(403).json({ error: "Insufficient permissions" });
    }
    next();
  };
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Session middleware - uses SESSION_SECRET from environment
  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) {
    console.warn("SESSION_SECRET not set. Using a generated secret for development.");
  }
  
  app.use(
    session({
      secret: sessionSecret || randomUUID(),
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        sameSite: "lax",
      },
    })
  );

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid credentials format" });
      }

      const { username, password } = parsed.data;
      const admin = await storage.getAdminByUsername(username);

      if (!admin) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const validPassword = await bcrypt.compare(password, admin.password);
      if (!validPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      if (!admin.isActive) {
        return res.status(403).json({ error: "Account is disabled" });
      }

      req.session.adminId = admin.id;

      // Log the login action
      await storage.createAuditLog({
        adminId: admin.id,
        action: "login",
        entityType: "admin",
        entityId: admin.id,
        ipAddress: req.ip || "unknown",
      });

      const { password: _, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/auth/me", requireAuth, async (req, res) => {
    try {
      const admin = await storage.getAdmin(req.session.adminId!);
      if (!admin) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: "Session invalid" });
      }
      const { password: _, ...adminWithoutPassword } = admin;
      res.json(adminWithoutPassword);
    } catch (error) {
      console.error("Auth check error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", requireAuth, async (req, res) => {
    const adminId = req.session.adminId;
    if (adminId) {
      await storage.createAuditLog({
        adminId,
        action: "logout",
        entityType: "admin",
        entityId: adminId,
      });
    }
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  // Withdrawal routes
  app.get("/api/withdrawals", requireAuth, async (req, res) => {
    try {
      const withdrawals = await storage.getWithdrawals();
      res.json(withdrawals);
    } catch (error) {
      console.error("Get withdrawals error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post(
    "/api/withdrawals/process",
    requireRole("super_admin", "finance_admin"),
    async (req, res) => {
      try {
        const parsed = withdrawalActionSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: "Invalid request format" });
        }

        const { withdrawalId, action, notes } = parsed.data;
        const withdrawal = await storage.getWithdrawal(withdrawalId);

        if (!withdrawal) {
          return res.status(404).json({ error: "Withdrawal not found" });
        }

        if (withdrawal.status !== "pending") {
          return res.status(400).json({ error: "Withdrawal already processed" });
        }

        const adminId = req.session.adminId!;
        const newStatus = action === "approve" ? "approved" : "rejected";

        const updated = await storage.updateWithdrawal(withdrawalId, {
          status: newStatus,
          processedBy: adminId,
          processedAt: new Date(),
          notes: notes || null,
        });

        // Log the action
        await storage.createAuditLog({
          adminId,
          action: `withdrawal_${action}`,
          entityType: "withdrawal",
          entityId: withdrawalId,
          oldValue: "pending",
          newValue: newStatus,
        });

        res.json(updated);
      } catch (error) {
        console.error("Process withdrawal error:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    }
  );

  // Config routes
  app.get("/api/config", requireAuth, async (req, res) => {
    try {
      const configs = await storage.getConfigs();
      res.json(configs);
    } catch (error) {
      console.error("Get config error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post(
    "/api/config",
    requireRole("super_admin", "finance_admin"),
    async (req, res) => {
      try {
        const parsed = configUpdateSchema.safeParse(req.body);
        if (!parsed.success) {
          return res.status(400).json({ error: "Invalid config format" });
        }

        const adminId = req.session.adminId!;
        const { name, value, description } = parsed.data;

        // Get old value for audit
        const existing = await storage.getConfig(name);
        const oldValue = existing?.value || null;

        const updated = await storage.upsertConfig({
          name,
          value,
          description: description || null,
          updatedBy: adminId,
        });

        // Log the action
        await storage.createAuditLog({
          adminId,
          action: "config_update",
          entityType: "config",
          entityId: name,
          oldValue,
          newValue: value,
        });

        res.json(updated);
      } catch (error) {
        console.error("Update config error:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    }
  );

  // Analytics routes
  app.get("/api/analytics", requireAuth, async (req, res) => {
    try {
      const [userCount, transactionStats, pendingWithdrawals] = await Promise.all([
        storage.getUserCount(),
        storage.getTransactionStats(),
        storage.getPendingWithdrawalsCount(),
      ]);

      // Generate sample time series data for charts
      const today = new Date();
      const userGrowth: { date: string; count: number }[] = [];
      const transactionVolume: { date: string; volume: string }[] = [];

      for (let i = 29; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateStr = date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
        
        userGrowth.push({
          date: dateStr,
          count: Math.floor(Math.random() * 50) + 10 + Math.floor(userCount / 30),
        });
        
        transactionVolume.push({
          date: dateStr,
          volume: (Math.random() * 10000 + 5000).toFixed(2),
        });
      }

      const totalFeesNum = parseFloat(transactionStats.totalFees) || 0;
      const feeDistribution = [
        { type: "Trading", amount: (totalFeesNum * 0.6).toFixed(2) },
        { type: "Withdrawal", amount: (totalFeesNum * 0.3).toFixed(2) },
        { type: "Deposit", amount: (totalFeesNum * 0.1).toFixed(2) },
      ];

      const analytics: AnalyticsData = {
        totalUsers: userCount,
        totalTransactions: transactionStats.totalCount,
        totalVolume: transactionStats.totalVolume || "0",
        totalFees: transactionStats.totalFees || "0",
        pendingWithdrawals,
        userGrowth,
        transactionVolume,
        feeDistribution,
      };

      res.json(analytics);
    } catch (error) {
      console.error("Get analytics error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Audit log routes
  app.get("/api/audit-logs/recent", requireAuth, async (req, res) => {
    try {
      const logs = await storage.getAuditLogs(undefined, 20);
      res.json(logs);
    } catch (error) {
      console.error("Get audit logs error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/audit-logs", requireAuth, async (req, res) => {
    try {
      const entityType = req.query.entityType as string | undefined;
      const logs = await storage.getAuditLogs(entityType === "config" ? "config" : undefined, 100);
      res.json(logs);
    } catch (error) {
      console.error("Get audit logs error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Seed initial admin and test data
  await seedInitialData();

  return httpServer;
}

async function seedInitialData() {
  try {
    // Check if admin exists
    const existingAdmin = await storage.getAdminByUsername("admin");
    if (!existingAdmin) {
      // Create default admin
      const hashedPassword = await bcrypt.hash("admin123", 10);
      await storage.createAdmin({
        username: "admin",
        email: "admin@platform.com",
        password: hashedPassword,
        role: "super_admin",
        isActive: true,
      });
      console.log("Created default admin user: admin / admin123");
    }

    // Seed some test users if none exist
    const userCount = await storage.getUserCount();
    if (userCount === 0) {
      const testUsers = [
        { username: "john_doe", email: "john@example.com", balance: "5420.50", isActive: true },
        { username: "jane_smith", email: "jane@example.com", balance: "12350.75", isActive: true },
        { username: "bob_trader", email: "bob@example.com", balance: "890.25", isActive: true },
        { username: "alice_crypto", email: "alice@example.com", balance: "25000.00", isActive: true },
        { username: "mike_investor", email: "mike@example.com", balance: "8750.00", isActive: true },
      ];

      for (const userData of testUsers) {
        await storage.createUser(userData);
      }
      console.log("Created test users");
    }

    // Seed some transactions if none exist
    const transactionStats = await storage.getTransactionStats();
    if (transactionStats.totalCount === 0) {
      const users = await storage.getAllUsers();
      const transactionTypes = ["trade", "deposit", "withdrawal"];
      
      for (const user of users.slice(0, 3)) {
        for (let i = 0; i < 5; i++) {
          const amount = (Math.random() * 1000 + 100).toFixed(2);
          const fee = (parseFloat(amount) * 0.001).toFixed(2);
          await storage.createTransaction({
            userId: user.id,
            type: transactionTypes[Math.floor(Math.random() * transactionTypes.length)],
            amount,
            fee,
            status: "completed",
          });
        }
      }
      console.log("Created test transactions");
    }

    // Seed some pending withdrawals if none exist
    const pendingCount = await storage.getPendingWithdrawalsCount();
    if (pendingCount === 0) {
      const users = await storage.getAllUsers();
      const wallets = [
        "0x742d35Cc6634C0532925a3b844Bc9e7595f8b3c2",
        "0x8Ba1f109551bD432803012645Ac136ddd64DBA72",
        "0xdD2FD4581271e230360230F9337D5c0430Bf44C0",
      ];

      for (let i = 0; i < 3; i++) {
        if (users[i]) {
          await storage.createWithdrawal({
            userId: users[i].id,
            amount: (Math.random() * 500 + 50).toFixed(2),
            walletAddress: wallets[i % wallets.length],
            status: "pending",
            notes: null,
          });
        }
      }
      console.log("Created test withdrawals");
    }

    // Seed default config if empty
    const configs = await storage.getConfigs();
    if (configs.length === 0) {
      const defaultConfigs = [
        { name: "trading_fee", value: "0.1", description: "Trading fee percentage" },
        { name: "withdrawal_fee", value: "0.5", description: "Withdrawal fee percentage" },
        { name: "deposit_fee", value: "0", description: "Deposit fee percentage" },
        { name: "min_withdrawal", value: "10", description: "Minimum withdrawal amount" },
        { name: "max_withdrawal", value: "10000", description: "Maximum withdrawal amount" },
      ];

      for (const cfg of defaultConfigs) {
        await storage.upsertConfig({
          ...cfg,
          updatedBy: null,
        });
      }
      console.log("Created default configs");
    }
  } catch (error) {
    console.error("Error seeding data:", error);
  }
}
